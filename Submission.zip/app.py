import os
from flask import Flask, render_template,request,redirect
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import random
import requests
import random
from sqlalchemy.orm import column_property, query
import pyperclip as pc

app = Flask(__name__)

basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///'+os.path.join(basedir,'data.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
Migrate(app,db)

data = {}

@app.route('/')   
def home_get():
    return render_template('index.html')

class url(db.Model):
    __tablename__ = 'url'
    id = db.Column(db.Integer,primary_key=True)
    short_url = db.Column(db.Text)
    orig_url = db.Column(db.Text)
    
    def __init__(self,short_url,orig_url):
        self.short_url = short_url
        self.orig_url = orig_url
    
    def __repr__(self):
        return '{} => {}'.format(self.orig_url,self.short_url)
        
short_url = None
orig_url = None

@app.route('/',methods=['POST'])
def home_post():
    if request.method == 'POST':
        orig_url = request.form.get('inp_1')
        response = requests.get(orig_url)
        if response.status_code == 200:    
            short_url = random.randint(100000,999999)
            data[short_url] = orig_url

            URL = url(short_url,orig_url)
            db.session.add(URL)
            db.session.commit()
       
    short = 'http://127.0.0.1:5000/sh/'+str(short_url) 
    pc.copy(short)
    return render_template('index.html',short_url = short_url)

@app.route('/history')
def history_get():
     URL = url.query.all()
     return render_template('history.html',URL=URL)

@app.route('/sh/<short_url>')
def redirection(short_url):
    long = url.query.filter_by(short_url=short_url).first()
    if long:
        long = long.orig_url
        return redirect(long)
        
    else:
        return f'<h1>Url doesnt exist</h1>'


if __name__ == '__main__':
    app.run(debug=True)